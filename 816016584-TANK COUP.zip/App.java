import javax.swing.JFrame;

public class App {
    public static void main(String[] args) {
        JFrame frame = new GameWindow();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
